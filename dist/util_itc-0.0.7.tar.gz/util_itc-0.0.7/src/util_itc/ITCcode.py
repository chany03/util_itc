import numpy as np
import math
from scipy.optimize import minimize
import matplotlib.pyplot as plt

class util_itc:

    def __init__(self, modeltype, choice, amt1, delay1, amt2, delay2):
        
        itc_input_checker(modeltype, choice, amt1, delay1, amt2, delay2)

        self.modeltype = modeltype
        self.choice = choice
        self.amt1 = amt1
        self.delay1 = delay1
        self.amt2 = amt2
        self.delay2 = delay2

def itc_input_checker(modeltype, choice, amt1, delay1, amt2, delay2):

        modeltypes = ['E', 'H', 'GH', 'Q']

        assert (type(modeltype) == str and modeltype in modeltypes), f'{modeltype} should be a string from the list "E" (exponential), "H" (hyperbolic), "GH" (generalized hyperbolic), and "Q" (quasi hyperbolic)'

        a, b = choice.shape
        assert (type(choice) == np.ndarray and (a == 1 or b == 1)), f'{choice} should be a vector'
        assert (choice.size > 2), f'{choice} should have at least 3 elements'
        assert (np.all(choice == 0 or choice == 1)), f'all elements in {choice} should be 1 or 0'

        a, b = amt1.shape
        assert (type(amt1) == np.ndarray and (a == 1 or b == 1)), f'{amt1} should be a vector'
        assert (amt1.size > 2), f'{amt1} should have at least 3 elements'
        assert (np.all(amt1 > 0)), f'{amt1} should be positive numbers only'

        c, d = delay1.shape
        assert (type(delay1) == np.ndarray and (c == 1 or d == 1)), f'{delay1} should be a vector'
        assert (delay1.size > 2), f'{delay1} should have at least 3 elements'
        assert (np.all(delay1 > 0)), f'{delay1} should be positive numbers only'

        e, f = amt2.shape
        assert (type(amt2) == np.ndarray and (e == 1 or f == 1)), f'{amt2} should be a vector'
        assert (amt2.size > 2), f'{amt2} should have at least 3 elements'
        assert (np.all(amt2 > 0)), f'{amt2} should be positive numbers only'

        g, h = delay2.shape
        assert (type(delay2) == np.ndarray and (g == 1 or h == 1)), f'{delay2} should be a vector'
        assert (delay2.size > 2), f'{delay2} should have at least 3 elements'
        assert (np.all(delay2 > 0)), f'{delay2} should be positive numbers only'

        assert (choice.size == amt1.size == delay1.size == amt2.size == delay2.size), 'all vectors should have equal size'

        return 'Input check completed successfully.'