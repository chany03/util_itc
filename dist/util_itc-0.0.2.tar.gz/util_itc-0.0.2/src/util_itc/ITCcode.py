def nines():
    return 999999999