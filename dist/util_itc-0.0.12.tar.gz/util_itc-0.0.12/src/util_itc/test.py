from ITCcode import util_itc

util_itc('e', [1, 1, 1], [1, 50, 10], 'asfd', [12, 23, 24], [100, 20, 30])